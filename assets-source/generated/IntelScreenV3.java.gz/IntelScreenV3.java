package uy.santipdr.siege.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import org.lwjgl.glfw.GLFW;
import uy.santipdr.siege.SiegeMod;

import java.util.ArrayList;
import java.util.List;

/** Third-generation responsive Intel database. */
public final class IntelScreenV3 extends Screen {
    private static final int BOSS_FRAME_COUNT = 6;
    private static final List<String> CATEGORIES = List.of(
            "ALL", "UNIT", "ADVANCED", "TANK", "BOSS", "ELITE", "SUPER-UNIT"
    );

    private final Screen parent;
    private final String requestedCategory;
    private final String requestedCode;
    private final List<SiegeButton> categoryButtons = new ArrayList<>();
    private final List<SiegeButton> entryButtons = new ArrayList<>();
    private final List<SiegeButton> navigationButtons = new ArrayList<>();

    private String category = "ALL";
    private int selected;
    private int listOffset;
    private int detailScroll;
    private int maxDetailScroll;
    private int detailBodyTop;

    private boolean wide;
    private boolean ultraCompact;
    private boolean compactSingleRow;
    private int sidebarWidth;
    private int categoryTop;
    private int listTop;
    private int listBottom;
    private int contentTop;
    private boolean requestedEntryApplied;

    public IntelScreenV3(Screen parent) {
        this(parent, null);
    }

    public IntelScreenV3(Screen parent, IntelEntry requestedEntry) {
        super(Component.translatable("siege.intel.title"));
        this.parent = parent;
        this.requestedCategory = requestedEntry == null ? null : requestedEntry.category();
        this.requestedCode = requestedEntry == null ? null : requestedEntry.code();
    }

    @Override
    protected void init() {
        SiegeUiSounds.resetHover();
        categoryButtons.clear();
        entryButtons.clear();
        navigationButtons.clear();

        wide = width >= 620 && height >= 340;
        ultraCompact = !wide && height < 285;
        compactSingleRow = !wide && width >= 350;
        applyRequestedEntry();
        if (wide) initWide(); else initCompact();
        refreshCategoryButtons();
        rebuildEntryNavigator();
    }

    private void applyRequestedEntry() {
        if (requestedEntryApplied || requestedCategory == null || requestedCode == null) return;
        requestedEntryApplied = true;
        if (!CATEGORIES.contains(requestedCategory)) return;
        category = requestedCategory;
        List<IntelEntry> files = filtered();
        for (int i = 0; i < files.size(); i++) {
            if (requestedCode.equals(files.get(i).code())) {
                selected = i;
                listOffset = 0;
                detailScroll = 0;
                return;
            }
        }
    }

    private void initWide() {
        sidebarWidth = Math.min(238, Math.max(174, width / 5));
        int margin = 10;
        int buttonHeight = height < 430 ? 18 : 20;
        int gap = 3;

        addRenderableWidget(new SiegeButton(margin, 9, sidebarWidth - margin * 2, 21,
                Component.literal("< ").append(Component.translatable("siege.intel.return")),
                b -> onClose(), 0xFFD64B4B));

        categoryTop = 64;
        int y = categoryTop;
        for (String value : CATEGORIES) {
            SiegeButton button = new SiegeButton(margin, y, sidebarWidth - margin * 2, buttonHeight,
                    Component.literal(categoryLabel(value)), b -> setCategory(value), categoryAccent(value));
            categoryButtons.add(button);
            addRenderableWidget(button);
            y += buttonHeight + gap;
        }

        listTop = y + 30;
        listBottom = height - 36;
        contentTop = 56;
    }

    private void initCompact() {
        sidebarWidth = 0;
        addRenderableWidget(new SiegeButton(6, 5, Math.min(72, Math.max(54, width / 5)), ultraCompact ? 16 : 18,
                Component.literal("< ").append(Component.translatable("siege.intel.return")),
                b -> onClose(), 0xFFD64B4B));

        int margin = 5;
        int gap = 2;
        int columns = compactSingleRow ? 7 : 4;
        int buttonHeight = ultraCompact ? 15 : 16;
        int buttonWidth = Math.max(38, (width - margin * 2 - gap * (columns - 1)) / columns);
        int rows = (CATEGORIES.size() + columns - 1) / columns;
        categoryTop = 29;

        for (int i = 0; i < CATEGORIES.size(); i++) {
            String value = CATEGORIES.get(i);
            int row = i / columns;
            int col = i % columns;
            int x = margin + col * (buttonWidth + gap);
            int y = categoryTop + row * (buttonHeight + 2);
            SiegeButton button = new SiegeButton(x, y, buttonWidth, buttonHeight,
                    Component.literal(categoryLabel(value)), b -> setCategory(value), categoryAccent(value));
            categoryButtons.add(button);
            addRenderableWidget(button);
        }

        listTop = categoryTop + rows * (buttonHeight + 2) + 2;
        listBottom = listTop + (ultraCompact ? 16 : 18);
        contentTop = listBottom + 4;
    }

    private void setCategory(String value) {
        if (category.equals(value)) return;
        SiegeUiSounds.click();
        category = value;
        selected = 0;
        listOffset = 0;
        detailScroll = 0;
        refreshCategoryButtons();
        rebuildEntryNavigator();
    }

    private void refreshCategoryButtons() {
        for (int i = 0; i < categoryButtons.size(); i++) {
            String value = CATEGORIES.get(i);
            SiegeButton button = categoryButtons.get(i);
            button.setMessage(Component.literal(categoryLabel(value)));
            button.setSelected(value.equals(category));
        }
    }

    private void rebuildEntryNavigator() {
        for (SiegeButton button : entryButtons) removeWidget(button);
        for (SiegeButton button : navigationButtons) removeWidget(button);
        entryButtons.clear();
        navigationButtons.clear();

        List<IntelEntry> files = filtered();
        if (files.isEmpty()) {
            selected = 0;
            listOffset = 0;
            return;
        }
        selected = Math.max(0, Math.min(selected, files.size() - 1));

        if (!wide) {
            int arrowWidth = Math.min(40, Math.max(28, width / 11));
            int navHeight = ultraCompact ? 16 : 18;
            SiegeButton previous = new SiegeButton(6, listTop, arrowWidth, navHeight, Component.literal("←"),
                    b -> stepEntry(-1), categoryAccent(category));
            SiegeButton next = new SiegeButton(width - arrowWidth - 6, listTop, arrowWidth, navHeight, Component.literal("→"),
                    b -> stepEntry(1), categoryAccent(category));
            navigationButtons.add(previous);
            navigationButtons.add(next);
            addRenderableWidget(previous);
            addRenderableWidget(next);
            return;
        }

        int arrowWidth = sidebarWidth - 20;
        SiegeButton previous = new SiegeButton(10, listTop, arrowWidth, 18,
                Component.literal("←  " + label("ANTERIOR", "PREVIOUS")),
                b -> stepEntry(-1), categoryAccent(category));
        SiegeButton next = new SiegeButton(10, height - 29, arrowWidth, 18,
                Component.literal("→  " + label("SIGUIENTE", "NEXT")),
                b -> stepEntry(1), categoryAccent(category));
        navigationButtons.add(previous);
        navigationButtons.add(next);
        addRenderableWidget(previous);
        addRenderableWidget(next);

        int visible = visibleEntries();
        ensureSelectedVisible(visible, files.size());
        int y = listTop + 22;
        for (int i = listOffset; i < files.size() && i < listOffset + visible; i++) {
            int index = i;
            IntelEntry entry = files.get(i);
            SiegeButton button = new SiegeButton(10, y, sidebarWidth - 20, 19,
                    Component.literal(entry.code() + "  " + entry.name()),
                    b -> selectEntry(index), categoryAccent(entry.category()));
            button.setSelected(i == selected);
            entryButtons.add(button);
            addRenderableWidget(button);
            y += 22;
        }
    }

    private void selectEntry(int index) {
        SiegeUiSounds.click();
        selected = index;
        detailScroll = 0;
        refreshEntrySelection();
    }

    private void stepEntry(int direction) {
        List<IntelEntry> files = filtered();
        if (files.isEmpty()) return;
        SiegeUiSounds.click();
        selected = Math.floorMod(selected + direction, files.size());
        detailScroll = 0;
        if (wide) {
            ensureSelectedVisible(visibleEntries(), files.size());
            rebuildEntryNavigator();
        }
    }

    private void ensureSelectedVisible(int visible, int size) {
        if (selected < listOffset) listOffset = selected;
        if (selected >= listOffset + visible) listOffset = selected - visible + 1;
        listOffset = Math.max(0, Math.min(listOffset, Math.max(0, size - visible)));
    }

    private void refreshEntrySelection() {
        if (!wide) return;
        for (int i = 0; i < entryButtons.size(); i++) {
            entryButtons.get(i).setSelected(listOffset + i == selected);
        }
    }

    private int visibleEntries() {
        return Math.max(1, (listBottom - (listTop + 22)) / 22);
    }

    private List<IntelEntry> filtered() {
        return IntelCatalog.filtered(category);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (delta == 0) return false;
        int direction = delta < 0 ? 1 : -1;

        if (wide && mouseX < sidebarWidth) {
            stepEntry(direction);
            return true;
        }
        if (!wide && mouseY < contentTop) {
            stepEntry(direction);
            return true;
        }
        if (mouseY >= detailBodyTop && maxDetailScroll > 0) {
            detailScroll = Math.max(0, Math.min(maxDetailScroll, detailScroll + direction * 2));
            return true;
        }

        stepEntry(direction);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_UP || keyCode == GLFW.GLFW_KEY_LEFT) {
            stepEntry(-1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_DOWN || keyCode == GLFW.GLFW_KEY_RIGHT) {
            stepEntry(1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_PAGE_UP) {
            detailScroll = Math.max(0, detailScroll - 5);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_PAGE_DOWN) {
            detailScroll = Math.min(maxDetailScroll, detailScroll + 5);
            return true;
        }
        if (keyCode >= GLFW.GLFW_KEY_0 && keyCode <= GLFW.GLFW_KEY_6) {
            int index = keyCode - GLFW.GLFW_KEY_0;
            if (index < CATEGORIES.size()) {
                setCategory(CATEGORIES.get(index));
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        SiegeMusic.ensurePlaying();
        SiegeBackgrounds.render(g, width, height, System.currentTimeMillis());
        int accent = categoryAccent(category);
        g.fill(0, 0, width, height, 0xA006090B);

        if (wide) renderWideChrome(g, accent); else renderCompactChrome(g, accent);

        List<IntelEntry> files = filtered();
        if (files.isEmpty()) {
            int centerX = wide ? (sidebarWidth + width) / 2 : width / 2;
            g.drawCenteredString(font, label("SIN EXPEDIENTES EN ESTA CATEGORÍA", "NO FILES IN THIS CATEGORY"),
                    centerX, height / 2 - 5, 0xFF8A9298);
            g.drawCenteredString(font, label("La base de datos todavía no contiene registros.", "The database does not contain records yet."),
                    centerX, height / 2 + 10, 0xFF68727A);
        } else {
            selected = Math.max(0, Math.min(selected, files.size() - 1));
            IntelEntry entry = files.get(selected);
            if (!wide) {
                String nav = String.format("%02d/%02d // %s %s", selected + 1, files.size(), entry.code(), entry.name());
                int maxWidth = Math.max(70, width - 100);
                g.drawCenteredString(font, font.plainSubstrByWidth(nav, maxWidth), width / 2,
                        listTop + (ultraCompact ? 4 : 5), 0xFFE2E5E7);
                renderFile(g, entry, 6, contentTop, width - 12, true);
            } else {
                renderFile(g, entry, sidebarWidth + 15, contentTop, width - sidebarWidth - 30, false);
                String counter = String.format("%02d/%02d", selected + 1, files.size());
                g.drawString(font, counter, width - 12 - font.width(counter), 17, 0xFF97A0A7, false);
            }
        }

        super.render(g, mouseX, mouseY, partialTick);
        SiegeUiSounds.updateHover(children());
    }

    private void renderWideChrome(GuiGraphics g, int accent) {
        g.fill(0, 0, width, 43, 0xF207090B);
        g.fill(0, 43, sidebarWidth, height, 0xF20B1014);
        g.fill(sidebarWidth, 43, width, height, 0x70080A0C);
        g.fill(sidebarWidth - 2, 43, sidebarWidth, height, accent);
        g.fill(0, 41, width, 43, accent);

        for (int y = 70; y < height; y += 28) {
            g.fill(0, y, sidebarWidth, y + 1, 0x1219A5BC);
        }

        int categoryBandTop = 45;
        int categoryBandBottom = categoryTop - 5;
        g.fill(0, categoryBandTop, sidebarWidth, categoryBandBottom, 0xFF0B1014);
        // No full-width underline here: it was visually colliding with the CATEGORIES label.
        g.fill(10, categoryBandTop + 5, 12, categoryBandBottom - 5, accent);

        int filesBandTop = listTop - 28;
        int filesBandBottom = listTop - 4;
        g.fill(0, filesBandTop, sidebarWidth, filesBandBottom, 0xFF0B1014);
        g.fill(10, filesBandBottom - 2, sidebarWidth - 10, filesBandBottom - 1, 0xFF24323A);

        g.drawCenteredString(font, label("BASE DE DATOS DE INTELIGENCIA", "INTELLIGENCE DATABASE"),
                (sidebarWidth + width) / 2, 16, 0xFFF0EEE8);
        g.drawString(font, "// " + label("CATEGORÍAS [0-6]", "CATEGORIES [0-6]"),
                16, categoryBandTop + 6, 0xFF89959D, false);
        g.drawString(font, "// " + label("EXPEDIENTES", "FILES") + " [" + filtered().size() + "]",
                12, filesBandTop + 7, 0xFF89959D, false);
    }

    private void renderCompactChrome(GuiGraphics g, int accent) {
        g.fill(0, 0, width, 26, 0xF207090B);
        g.fill(0, 25, width, 27, accent);
        g.drawCenteredString(font, label("INTEL // CLASIFICADO", "INTEL // CLASSIFIED"), width / 2, 8, 0xFFF0EEE8);
        g.fill(0, contentTop - 3, width, contentTop - 2, 0x4C454E55);
    }

    private void renderFile(GuiGraphics g, IntelEntry entry, int x, int y, int availableWidth, boolean compactMode) {
        IntelEntry.IntelText text = entry.text(spanish());
        boolean advanced = entry.category().equals("ADVANCED");
        int accent = categoryAccent(entry.category());
        int paper = advanced ? 0xFFE0E7EB : 0xFFE7DFC9;
        int paperDark = advanced ? 0xFFB8C5CD : 0xFFC7BCA1;
        int ink = advanced ? 0xFF13232D : 0xFF29261F;
        int muted = advanced ? 0xFF53646E : 0xFF6B6454;
        int warning = advanced ? 0xFF842C3C : 0xFF8A2E27;
        int bottom = height - 7;
        if (bottom <= y + 32 || availableWidth < 90) return;

        g.fill(x + 3, y + 3, x + availableWidth + 3, bottom + 3, 0x66000000);
        g.fill(x, y, x + availableWidth, bottom, paper);
        g.fill(x, y, x + availableWidth, y + 3, accent);
        g.fill(x, y, x + 1, bottom, paperDark);
        g.fill(x + availableWidth - 1, y, x + availableWidth, bottom, paperDark);

        int pad = compactMode ? 5 : 10;
        int headerX = x + pad;
        int headerY = y + (ultraCompact && compactMode ? 5 : 7);
        int innerWidth = availableWidth - pad * 2;
        int row = ultraCompact && compactMode ? 10 : 12;

        String ref = label("EXPEDIENTE", "FILE") + " " + entry.code();
        g.drawString(font, ref, headerX, headerY, muted, false);
        if (availableWidth > 230) {
            String stamp = label("CLASIFICADO", "CLASSIFIED");
            g.drawString(font, stamp, x + availableWidth - pad - font.width(stamp), headerY, accent, false);
        }
        g.drawString(font, entry.name(), headerX, headerY + row, ink, false);
        String threatLevel = entry.threat() > 0 ? stars(entry.threat()) : label("SIN DATOS", "NO DATA");
        String threat = label("AMENAZA", "THREAT") + " " + threatLevel + "   HP " + entry.hp();
        if (!"N/D".equals(entry.defense())) threat += "   DEF " + entry.defense();
        g.drawString(font, font.plainSubstrByWidth(threat, innerWidth), headerX, headerY + row * 2, warning, false);

        int mediaTop = headerY + (ultraCompact && compactMode ? 31 : 39);
        int imageWidth;
        if (compactMode && ultraCompact) imageWidth = Math.min(96, Math.max(72, availableWidth * 25 / 100));
        else if (compactMode) imageWidth = Math.min(112, Math.max(80, availableWidth * 30 / 100));
        else imageWidth = Math.min(292, Math.max(142, availableWidth * 40 / 100));

        int reserve = compactMode ? (ultraCompact ? 48 : 60) : 80;
        int maxImageHeight = Math.max(42, bottom - mediaTop - reserve);
        imageWidth = Math.min(imageWidth, Math.max(72, maxImageHeight * 16 / 9));
        int imageHeight = imageWidth * 9 / 16;
        int imageX = headerX;
        int mediaFrame = bossFrame(entry);
        ResourceLocation portrait = portraitTexture(entry, mediaFrame);
        g.fill(imageX - 2, mediaTop - 2, imageX + imageWidth + 2, mediaTop + imageHeight + 2, paperDark);
        g.blit(portrait, imageX, mediaTop, imageWidth, imageHeight, 0, 0, 640, 360, 640, 360);
        g.fill(imageX, mediaTop, imageX + imageWidth, mediaTop + 2, accent);

        int metaX = imageX + imageWidth + (compactMode ? 6 : 13);
        int metaWidth = Math.max(48, x + availableWidth - pad - metaX);
        int metaEnd = mediaTop;
        if (metaWidth >= 48) {
            if (compactMode) {
                metaEnd = drawMetaInline(g, label("ORIGEN", "ORIGIN"), text.origin(), metaX, metaEnd,
                        metaWidth, muted, ink);
                metaEnd = drawMetaInline(g, label("ESTADO", "STATUS"), text.status(), metaX,
                        metaEnd + 2, metaWidth, muted, warning);
            } else {
                metaEnd = drawMeta(g, label("ORIGEN", "ORIGIN"), text.origin(), metaX, metaEnd, metaWidth, muted, ink);
                metaEnd = drawMeta(g, label("ESTADO", "STATUS"), text.status(), metaX, metaEnd + 3, metaWidth, muted, warning);
                if (metaWidth >= 90) {
                    metaEnd = drawMeta(g, label("ARMAMENTO", "ARMAMENT"), text.armament(), metaX, metaEnd + 3, metaWidth, muted, ink);
                    metaEnd = drawMeta(g, label("VARIANTES", "VARIANTS"), text.variants(), metaX, metaEnd + 3, metaWidth, muted, ink);
                }
            }
        }

        int bodyTop = Math.max(mediaTop + imageHeight + (compactMode ? 6 : 9), metaEnd + (compactMode ? 4 : 7));
        int bodyBottom = bottom - 12;
        detailBodyTop = bodyTop;
        int bodyWidth = innerWidth;

        List<DetailLine> lines = new ArrayList<>();
        if (compactMode) {
            if (ultraCompact) {
                appendWrapped(lines,
                        label("ARM.", "ARM.") + " " + text.armament() + "  //  " + label("VAR.", "VAR.") + " " + text.variants(),
                        bodyWidth, muted);
            } else {
                appendWrapped(lines, label("ARMAMENTO", "ARMAMENT") + ": " + text.armament(), bodyWidth, muted);
                appendWrapped(lines, label("VARIANTES", "VARIANTS") + ": " + text.variants(), bodyWidth, muted);
            }
            lines.add(blankLine());
        }
        appendWrapped(lines, label("PERFIL OPERATIVO", "OPERATIONAL PROFILE"), bodyWidth, accentInk(entry.category()));
        appendWrapped(lines, text.description(), bodyWidth, ink);
        lines.add(blankLine());
        appendWrapped(lines, label("ADVERTENCIA TÁCTICA", "TACTICAL ADVISORY"), bodyWidth, warning);
        appendWrapped(lines, text.advisory(), bodyWidth, warning);

        if (bodyBottom > bodyTop + 3) {
            int lineHeight = ultraCompact && compactMode ? 10 : 11;
            int visibleLines = Math.max(1, (bodyBottom - bodyTop) / lineHeight);
            maxDetailScroll = Math.max(0, lines.size() - visibleLines);
            detailScroll = Math.max(0, Math.min(detailScroll, maxDetailScroll));

            g.fill(headerX, bodyTop - 3, x + availableWidth - pad, bodyTop - 2, paperDark);
            g.enableScissor(headerX, bodyTop, x + availableWidth - pad, bodyBottom);
            int lineY = bodyTop - detailScroll * lineHeight;
            for (DetailLine line : lines) {
                if (lineY >= bodyTop - lineHeight && lineY < bodyBottom) {
                    g.drawString(font, line.value(), headerX, lineY, line.color(), false);
                }
                lineY += lineHeight;
            }
            g.disableScissor();
        } else {
            maxDetailScroll = 0;
        }

        if (maxDetailScroll > 0) {
            String hint = ultraCompact && compactMode
                    ? label("RUEDA: LEER MÁS", "WHEEL: READ MORE")
                    : label("RUEDA SOBRE EL TEXTO: LEER MÁS", "WHEEL OVER TEXT: READ MORE");
            g.drawString(font, font.plainSubstrByWidth(hint, innerWidth), headerX, bottom - 10, muted, false);
            int lineHeight = ultraCompact && compactMode ? 10 : 11;
            int visibleLines = Math.max(1, (bodyBottom - bodyTop) / lineHeight);
            int trackX = x + availableWidth - 4;
            int trackHeight = Math.max(8, bodyBottom - bodyTop);
            int thumbHeight = Math.max(8, trackHeight * visibleLines / Math.max(visibleLines, lines.size()));
            int thumbY = bodyTop + (trackHeight - thumbHeight) * detailScroll / maxDetailScroll;
            g.fill(trackX, bodyTop, trackX + 2, bodyTop + trackHeight, 0x44384143);
            g.fill(trackX, thumbY, trackX + 2, thumbY + thumbHeight, accent);
        }
    }

    private int drawMeta(GuiGraphics g, String label, String value, int x, int y, int width,
                         int labelColor, int valueColor) {
        if (width <= 10) return y;
        g.drawString(font, label + ":", x, y, labelColor, false);
        int nextY = y + 10;
        for (FormattedCharSequence line : font.split(Component.literal(value), width)) {
            g.drawString(font, line, x, nextY, valueColor, false);
            nextY += 10;
        }
        return nextY;
    }

    private int drawMetaInline(GuiGraphics g, String label, String value, int x, int y, int width,
                               int labelColor, int valueColor) {
        if (width <= 10) return y;
        String prefix = label + ": ";
        int prefixWidth = font.width(prefix);
        if (prefixWidth + font.width(value) <= width) {
            g.drawString(font, prefix, x, y, labelColor, false);
            g.drawString(font, value, x + prefixWidth, y, valueColor, false);
            return y + 10;
        }
        g.drawString(font, label + ":", x, y, labelColor, false);
        int nextY = y + 9;
        for (FormattedCharSequence line : font.split(Component.literal(value), width)) {
            g.drawString(font, line, x, nextY, valueColor, false);
            nextY += 9;
        }
        return nextY;
    }

    private void appendWrapped(List<DetailLine> target, String value, int width, int color) {
        for (FormattedCharSequence line : font.split(Component.literal(value), Math.max(24, width))) {
            target.add(new DetailLine(line, color));
        }
    }

    private DetailLine blankLine() {
        return new DetailLine(FormattedCharSequence.forward(" ", net.minecraft.network.chat.Style.EMPTY), 0x00000000);
    }

    private int accentInk(String category) {
        return switch (category) {
            case "ADVANCED" -> 0xFF245F86;
            case "TANK" -> 0xFF8A571B;
            default -> 0xFF8C302B;
        };
    }

    private int bossFrame(IntelEntry entry) {
        if (!entry.category().equals("BOSS") || !SiegeConfig.animatedIntel || SiegeConfig.reducedMotion) return 0;
        return Math.floorMod((int) (System.currentTimeMillis() / 450L), BOSS_FRAME_COUNT);
    }

    private ResourceLocation portraitTexture(IntelEntry entry, int frame) {
        String image = entry.image();
        if (entry.category().equals("BOSS")) {
            image = image.substring(0, image.length() - 2) + String.format("%02d", frame);
        }
        return new ResourceLocation(SiegeMod.MOD_ID, "textures/gui/intel/" + image + ".png");
    }

    private String categoryLabel(String value) {
        int number = CATEGORIES.indexOf(value);
        int count = IntelCatalog.count(value);
        if (!wide) {
            String shortName = switch (value) {
                case "ALL" -> "ALL";
                case "UNIT" -> spanish() ? "UNI" : "UNIT";
                case "ADVANCED" -> "ADV";
                case "TANK" -> spanish() ? "TNQ" : "TNK";
                case "BOSS" -> spanish() ? "JEF" : "BOS";
                case "ELITE" -> "ELT";
                case "SUPER-UNIT" -> "SUP";
                default -> value;
            };
            return number + " " + shortName + "·" + count;
        }

        String name = switch (value) {
            case "ALL" -> label("TODAS", "ALL");
            case "UNIT" -> label("UNIDADES", "UNITS");
            case "ADVANCED" -> label("AVANZADOS", "ADVANCED");
            case "TANK" -> label("TANQUES", "TANKS");
            case "BOSS" -> label("JEFES", "BOSSES");
            case "ELITE" -> label("ÉLITES", "ELITES");
            case "SUPER-UNIT" -> label("SUPERUNIDADES", "SUPER-UNITS");
            default -> value;
        };
        return number + " // " + name + "  [" + count + "]";
    }

    private int categoryAccent(String value) {
        return switch (value) {
            case "ALL" -> 0xFF55BFD9;
            case "UNIT" -> 0xFFD94A4A;
            case "ADVANCED" -> 0xFF2F80FF;
            case "TANK" -> 0xFFD98A2B;
            case "BOSS" -> 0xFFB5162D;
            case "ELITE" -> 0xFF9B59D0;
            case "SUPER-UNIT" -> 0xFFE0B93F;
            default -> 0xFFB8C0C8;
        };
    }

    private String stars(int count) {
        return "★".repeat(Math.max(0, count)) + "☆".repeat(Math.max(0, 5 - count));
    }

    private boolean spanish() {
        return minecraft != null && minecraft.getLanguageManager().getSelected().startsWith("es_");
    }

    private String label(String es, String en) {
        return spanish() ? es : en;
    }

    @Override
    public void onClose() {
        SiegeUiSounds.back();
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private record DetailLine(FormattedCharSequence value, int color) { }
}
